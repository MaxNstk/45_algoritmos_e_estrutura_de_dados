package exemplo;

public class Aresta {
	
	public Vertice destino;
	public int peso;
	
	public Aresta(){}
	
	public Aresta(Vertice destino, int peso)
	{
		this.destino = destino;
		this.peso = peso;
	}	
	
}






























